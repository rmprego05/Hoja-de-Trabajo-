Universidad Francisco Marroquín
FCE - Programación I

## Hoja de Trabajo: tic-tac-toe

Instrucciones:

1. Descargar este *gist*.
2. Crear un nuevo repositorio público.
3. Copiar el archivo `main.py` a su repositorio recién creado y añadir las funcionalidades indicadas en los comentarios del archivo:
    - *update_board(...)*
    - *check_for_winner(...)*
4. Hacer commits según considere necesario.
5. Testear funcionalidades creadas en el mismo `main.py`.
6. Enviar link de repositorio por correo a auxiliar y catedrático.

Tiempo de entrega: 5:20PM (final de período de clase).
Ponderación: 2 puntos.
